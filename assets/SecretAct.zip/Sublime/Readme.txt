
1. Right click & RUN AS ADMINISTRATOR the "1. Sublime Text Disable Key Validation.bat" file to disable auto check for key.
2. Open "2. Working Key.txt" file and copy the key by select all text.
3. Paste the key in sublime text 3 under menu "HELP => ENTER LICENCE"



(Provided By DailyFile.Host)


- Secure File Hosting with 2GB per file limit
http://dailyfile.host/ is free & secure file hosting with 2GB file limit. You can upload up-to 50 file at same time.
